﻿namespace AI_Graphs
{
	public partial class AppShell : Shell
	{
		public AppShell()
		{
			InitializeComponent();
			//Routing.RegisterRoute(nameof(MessageDetails), typeof(MessageDetails));
		}
	}
}
