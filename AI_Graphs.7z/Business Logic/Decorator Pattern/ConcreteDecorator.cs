﻿using AI_Graphs.Template_Method_Pattern;

namespace AI_Graphs.Business_Logic.Decorator_Pattern
{
	// Concrete decorator for adding image-saving functionality
	//public class ImageSavingDecorator : IDrawingDecorator
	//{
	//	public ImageSavingDecorator(IDrawingTemplate drawingMethod) : base(drawingMethod) { }

	//	public override void Draw()
	//	{
	//		// Call the draw method of the wrapped component
	//		base.Draw();

	//		// Additional behavior: save the drawn image to a file
	//		// Your code for saving the image here
	//	}
	//}
}
